@echo off
REM ==========================================
REM Inspector C5 - Atualizar e Abrir
REM ==========================================
REM Rode ESTE arquivo sempre que for usar o Inspector localmente (fica dentro da
REM pasta "Front" instalada pelo Inspector_Launcher.bat). Sempre baixa a versao mais
REM recente do pacote e substitui os arquivos NESTA MESMA pasta (nunca cria uma
REM pasta "Front" dentro dela) - depois abre o Chrome ja configurado.
setlocal
set "URL_ZIP=https://raw.githubusercontent.com/luanmanini-im/c5-inspector/main/Front.zip"
set "PASTA_ATUAL=%~dp0"
set "ZIP_TEMP=%TEMP%\Inspector_Front_%RANDOM%.zip"
set "EXTRACAO_TEMP=%TEMP%\Inspector_Extract_%RANDOM%"

echo Verificando atualizacoes do Inspector...
powershell -NoProfile -ExecutionPolicy Bypass -Command "try { Invoke-WebRequest -Uri '%URL_ZIP%' -OutFile '%ZIP_TEMP%' -UseBasicParsing -ErrorAction Stop; Expand-Archive -Path '%ZIP_TEMP%' -DestinationPath '%EXTRACAO_TEMP%' -Force -ErrorAction Stop; $h = Get-ChildItem -Path '%EXTRACAO_TEMP%' -Filter 'Q.A.html' -Recurse -File -ErrorAction Stop | Select-Object -First 1; if (-not $h) { throw 'Q.A.html nao encontrado no pacote baixado.' }; Copy-Item -Path (Join-Path $h.DirectoryName '*') -Destination '%PASTA_ATUAL%' -Recurse -Force -ErrorAction Stop } catch { Write-Host ('Erro ao atualizar: ' + $_.Exception.Message); exit 1 }"
if errorlevel 1 (
    echo.
    echo Nao foi possivel atualizar agora ^(sem internet ou o servidor esta fora^). Tentando abrir com os arquivos ja existentes...
)

del "%ZIP_TEMP%" >nul 2>&1
rmdir /s /q "%EXTRACAO_TEMP%" >nul 2>&1

if not exist "%PASTA_ATUAL%Q.A.html" (
    echo.
    echo Q.A.html nao encontrado nesta pasta e a atualizacao falhou. Nao e possivel abrir o Inspector.
    pause
    exit /b 1
)

echo Iniciando o Inspector C5...
start "" chrome.exe --disable-web-security --user-data-dir="C:\ChromeDev" "%PASTA_ATUAL%Q.A.html"
exit
