// ==========================================
// PROXY HELPER - Inspector C5
// Wrapper para requisições com CORS bypass
// ==========================================

/**
 * Faz uma requisição HTTP usando a extensão como proxy
 * @param {string} url - URL da requisição
 * @param {object} options - Opções (method, headers, body)
 * @returns {Promise<Response>}
 */
async function fetchWithBypass(url, options = {}) {
  return new Promise((resolve, reject) => {
    // Verifica se está rodando como extensão Chrome
    if (typeof chrome !== 'undefined' && chrome.runtime && chrome.runtime.sendMessage) {
      chrome.runtime.sendMessage({
        action: 'fetchWithBypass',
        url: url,
        method: options.method || 'GET',
        headers: options.headers || {},
        body: options.body
      }, (response) => {
        if (response.success) {
          // Simula Response object do fetch
          const fakeResponse = {
            status: response.data.status,
            statusText: response.data.statusText,
            ok: response.data.status >= 200 && response.data.status < 300,
            headers: new Map(Object.entries(response.data.headers)),
            getContentText: () => response.data.body,
            getResponseCode: () => response.data.status,
            text: () => Promise.resolve(response.data.body),
            json: () => Promise.resolve(JSON.parse(response.data.body))
          };
          resolve(fakeResponse);
        } else {
          reject(new Error(response.error));
        }
      });
    } else {
      // Fallback para requisição direta (se não estiver em extensão)
      fetch(url, options)
        .then(resolve)
        .catch(reject);
    }
  });
}

/**
 * Substitui o fetch global para usar proxy
 * Execute este script ANTES de qualquer outro que use fetch
 */
if (typeof chrome !== 'undefined' && chrome.runtime) {
  const originalFetch = window.fetch;
  
  window.fetch = function(url, options) {
    // URLs que precisam de bypass
    const bypassUrls = [
      'script.google.com',
      'consultatributos.com.br',
      'totvs.com.br'
    ];
    
    const needsBypass = bypassUrls.some(domain => url.includes(domain));
    
    if (needsBypass) {
      return fetchWithBypass(url, options);
    } else {
      return originalFetch.call(this, url, options);
    }
  };
  
  console.log('[Inspector C5] Proxy Helper ativo - fetch() interceptado');
}
