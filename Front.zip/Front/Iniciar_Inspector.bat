@echo off
REM Descobre onde o arquivo bat está rodando e aponta para o html na mesma pasta
set "CAMINHO_HTML=%~dp0Q.A.html"

echo Iniciando o Inspector C5...
start "" chrome.exe --disable-web-security --user-data-dir="C:\ChromeDev" "%CAMINHO_HTML%"
exit