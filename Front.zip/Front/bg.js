// ==========================================
// BACKGROUND SERVICE WORKER - Inspector C5
// Proxy Local CORS Bypass para IP Restrito
// ==========================================

chrome.action.onClicked.addListener((tab) => {
  chrome.tabs.create({ url: chrome.runtime.getURL('5.3.html') });
});

// Interceptor para requisições (bloqueia CORS)
chrome.webRequest.onBeforeSendHeaders.addListener(
  (details) => {
    let headers = details.requestHeaders || [];
    
    // Remove headers problemáticos
    headers = headers.filter(h => {
      const name = h.name.toLowerCase();
      return name !== 'origin' && name !== 'referer';
    });
    
    return { requestHeaders: headers };
  },
  {
    urls: [
      'https://script.google.com/*',
      'https://consultatributos.com.br/*',
      'https://*.totvs.com.br/*'
    ]
  },
  ['requestHeaders', 'extraHeaders']
);

// Listener para mensagens do frontend
chrome.runtime.onMessage.addListener((request, sender, sendResponse) => {
  if (request.action === 'fetchWithBypass') {
    fetch(request.url, {
      method: request.method || 'GET',
      headers: request.headers || {},
      body: request.body || undefined,
      credentials: 'include'
    })
    .then(response => response.text().then(text => ({ 
      status: response.status, 
      statusText: response.statusText,
      headers: Object.fromEntries(response.headers),
      body: text 
    })))
    .then(data => sendResponse({ success: true, data }))
    .catch(error => sendResponse({ success: false, error: error.message }));
    
    return true;
  }
});

console.log('[Inspector C5] Background Worker iniciado - CORS Bypass ATIVO');