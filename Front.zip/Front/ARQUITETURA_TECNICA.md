# 🔗 Integração Técnica: Backend + Proxy Local

## Arquitetura Completa

```
┌─────────────────────────────────────────────────────────────────┐
│                    Browser (Chrome)                              │
│ ┌───────────────────────────────────────────────────────────┐   │
│ │          5.3.html (Interface da Aplicação)                │   │
│ │  ┌─────────────────────────────────────────────────────┐  │   │
│ │  │  fetch('https://script.google.com/macros/s/...') │  │   │
│ │  └─────────────────────────────────────────────────────┘  │   │
│ │                          ↓                                 │   │
│ │  ┌─────────────────────────────────────────────────────┐  │   │
│ │  │  proxy-helper.js (Interceptor de fetch)            │  │   │
│ │  │  - Detecta URLs que precisam bypass                │  │   │
│ │  │  - Envia msg via chrome.runtime.sendMessage()      │  │   │
│ │  └─────────────────────────────────────────────────────┘  │   │
│ │                          ↓                                 │   │
│ └───────────────────────────────────────────────────────────┘   │
│                          ↓                                       │
│ ┌───────────────────────────────────────────────────────────┐   │
│ │          Extensão Chrome (Service Worker)                 │   │
│ │ ┌─────────────────────────────────────────────────────┐  │   │
│ │ │  bg.js (Proxy Backend)                              │  │   │
│ │ │  - chrome.runtime.onMessage listener                │  │   │
│ │ │  - Remove headers de CORS                           │  │   │
│ │ │  - Faz fetch com credentials: 'include'             │  │   │
│ │ └─────────────────────────────────────────────────────┘  │   │
│ │                          ↓                                 │   │
│ └───────────────────────────────────────────────────────────┘   │
└─────────────────────────────────────────────────────────────────┘
                          ↓
                         INTERNET
                          ↓
┌─────────────────────────────────────────────────────────────────┐
│           Google Apps Script - Backend 5.3.1.gs                 │
│ ┌───────────────────────────────────────────────────────────┐   │
│ │  doGet(e) - Router de Ações                              │   │
│ │  - ?action=login                                         │   │
│ │  - ?action=listar_clientes                              │   │
│ │  - ?action=produto&cliente=X&sku=Y                      │   │
│ │  - ?action=saneamento_tributario&email=X&sku=Y         │   │
│ │  ... etc                                                 │   │
│ └───────────────────────────────────────────────────────────┘   │
└─────────────────────────────────────────────────────────────────┘
                          ↓
                         INTERNET
                          ↓
┌─────────────────────────────────────────────────────────────────┐
│                    Google Sheets                                 │
│  - Aba "Usuarios" (autenticação)                                │
│  - Aba "Clientes" (configuração de conexão)                    │
└─────────────────────────────────────────────────────────────────┘
                          ↓
┌─────────────────────────────────────────────────────────────────┐
│              APIs Externas (com IP Restrito)                    │
│  - TOTVS Consinco (ERP)                                         │
│  - Consulta Tributos IMendes (Saneamento)                      │
└─────────────────────────────────────────────────────────────────┘
```

## Fluxo de Dados - Exemplo: Saneamento Tributário

### 1. **Frontend** (5.3.html)
```javascript
// Usuário clica "Atualizar Saneamento"
dispararSaneamentoTributario() {
  const emailUsuario = localStorage.getItem('imendes_usuario');
  const url = WEB_APP_URL + 
    "?action=saneamento_tributario" +
    "&email=" + emailUsuario +
    "&sku=" + skuProdutoAtual +
    "&adequarCgo=" + adequarCgo;
  
  // Faz requisição (será interceptada por proxy-helper.js)
  fetch(url)
    .then(response => response.json())
    .then(data => console.log(data));
}
```

### 2. **Proxy Helper** (proxy-helper.js)
```javascript
// fetch() interceptado - detecta URL do script.google.com
if (url.includes('script.google.com')) {
  // Envia para o background worker da extensão
  chrome.runtime.sendMessage({
    action: 'fetchWithBypass',
    url: url,
    method: 'GET'
  }, (response) => {
    // Retorna resposta simulando objeto Response
    resolve(response.data);
  });
}
```

### 3. **Background Worker** (bg.js)
```javascript
// Recebe mensagem do content script
chrome.runtime.onMessage.addListener((request, sender, sendResponse) => {
  if (request.action === 'fetchWithBypass') {
    // Remove headers de CORS e faz requisição
    fetch(request.url, {
      method: request.method || 'GET',
      headers: removeCorHeaders(request.headers),
      credentials: 'include'
    })
    .then(response => response.text())
    .then(body => sendResponse({ 
      success: true, 
      data: { status: 200, body: body }
    }));
  }
});
```

### 4. **Backend Google Apps Script** (5.3.1.gs)
```javascript
// Recebe requisição GET
function doGet(e) {
  const action = e.parameter.action; // "saneamento_tributario"
  const email = e.parameter.email;
  const sku = e.parameter.sku;
  
  if (action === 'saneamento_tributario') {
    // Chama função de saneamento
    const resultado = enviarSaneamentoTributario(email, sku, adequarCgo);
    
    // Retorna JSON
    return ContentService.createTextOutput(
      JSON.stringify(resultado)
    ).setMimeType(ContentService.MimeType.JSON);
  }
}

// Função implementada
function enviarSaneamentoTributario(email, sku, adequarCgo) {
  // 1. Busca token do usuário (coluna E da aba Usuarios)
  const tokenSessao = obterTokenSessaoUsuario(email);
  
  // 2. Monta payload
  const payload = {
    login: {
      email: email,
      tokenSession: tokenSessao
    },
    tipoSaneamento: 1,
    codigos: [sku]
  };
  
  // 3. Envia para API de saneamento
  const response = UrlFetchApp.fetch(
    "https://consultatributos.com.br:8443/totvs/v1/portal/jobs/saneamento-tributario",
    {
      method: "post",
      contentType: "application/json",
      payload: JSON.stringify(payload),
      muteHttpExceptions: true
    }
  );
  
  // 4. Retorna resultado
  return {
    sucesso: response.getResponseCode() === 200,
    dados: parseJsonSeguro(response.getContentText(), {})
  };
}
```

### 5. **Resposta** (volta ao frontend)
```javascript
// Frontend recebe:
{
  "sucesso": true,
  "mensagem": "Saneamento tributário enviado com sucesso.",
  "dados": { ... }
}
```

## Por Que Não Funciona Sem o Proxy?

### Cenário SEM Proxy (Tenta fetch direto):
```
Browser
  ↓
  fetch('https://script.google.com/...')
  ↓
  [CORS BLOQUEADO]
  ❌ Erro: "Access-Control-Allow-Origin" header não encontrado
```

### Cenário COM Proxy (Extensão Chrome):
```
Browser (proxy-helper.js)
  ↓
  chrome.runtime.sendMessage() [sem restrição CORS]
  ↓
  Extensão (bg.js)
  ↓
  fetch() nativa do Chrome [sem restrição CORS dentro de extensão]
  ↓
  script.google.com
  ✅ Funciona!
```

## Permissões Necessárias no manifest.json

```json
{
  "host_permissions": [
    "<all_urls>",                          // Permite qualquer URL
    "https://script.google.com/*",         // Google Apps Script
    "https://consultatributos.com.br/*",   // API de Saneamento
    "https://*.totvs.com.br/*"            // TOTVS ERP
  ]
}
```

## Configuração de Headers

O `bg.js` remove:
- `Origin` (identificação de origem)
- `Referer` (página de origem)

E a requisição é feita com `credentials: 'include'` para manter cookies/sessions.

## Fluxo Alternativo: Modo VPN

Se o cliente está configurado como `modoVpn: SIM`:

```javascript
// No 5.3.html (linha ~823 - função fetchHibrido)
if (cliente.modoVpn) {
  // Requisição DIRETA para URL local da TOTVS (sem passar por Apps Script)
  // Não precisa de proxy, pois está na rede local
  const url = `${clienteData.urlBase}/CadastrosEstruturaisAPI/api/v1/...`;
  fetch(url) // Requisição local, sem CORS
}
```

## Resumo da Integração

| Componente | Função | Localização |
|-----------|--------|-------------|
| **5.3.html** | Interface do usuário | Local (extensão Chrome) |
| **proxy-helper.js** | Interceptor de fetch | Local (extensão Chrome) |
| **bg.js** | Background proxy | Local (extensão Chrome) |
| **manifest.json** | Config da extensão | Local (extensão Chrome) |
| **5.3.1.gs** | Backend/Router | Google Apps Script (nuvem) |
| **Google Sheets** | Banco de dados | Google Drive |

---

**Versão:** 5.3.0  
**Arquitetura:** Híbrido Local + Nuvem  
**Segurança:** Desenvolvimento apenas (desabilita CORS localmente)
