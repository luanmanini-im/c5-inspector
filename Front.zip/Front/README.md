# Inspector C5 - Versão Local com CORS Bypass

Extensão Chrome para rodar o Inspector C5 localmente sem erros de CORS ao conectar em servidores com IP restrito.

## 📦 Estrutura de Arquivos

```
Inspector Local/5.3/
├── 5.3.html           (Interface - mesma do servidor)
├── manifest.json      (Configuração da extensão)
├── bg.js             (Background service worker - proxy)
├── proxy-helper.js   (Helper para interceptar fetch)
├── Iniciar_Inspector.bat (Script de inicialização)
└── README.md         (Este arquivo)
```

## 🚀 Como Usar

### Opção 1: Usar o arquivo .bat (RECOMENDADO)

```bash
# Duplo-clique em:
Iniciar_Inspector.bat
```

Isso abre o Chrome com a extensão já carregada e desabilita a segurança CORS.

### Opção 2: Carregar extensão manualmente

1. Abra o Chrome/Brave
2. Acesse: `chrome://extensions/`
3. Ative **Modo de desenvolvedor** (canto superior direito)
4. Clique **Carregar extensão sem compactação**
5. Selecione a pasta `C:\Users\User\Desktop\Inspector Local\5.3`
6. A extensão aparecerá na lista

### Opção 3: Usar Chrome com flags desabilitadas

```bash
chrome.exe --disable-web-security --user-data-dir="C:\ChromeDev" "file:///.../5.3.html"
```

## 🔧 Como Integra com o Backend

O arquivo **5.3.html** está configurado para usar:

```javascript
const WEB_APP_URL = "https://script.google.com/macros/s/AKfycbz4GwJtw2vBcaqwfkMnCMOHKPK9xfsr5jgc5wpqZ4z8FDlsj6OLVACMvZT3huqtqel1uA/exec";
```

**Requisições suportadas:**
- ✅ Login na aplicação
- ✅ Buscar produtos (SKU/EAN)
- ✅ Consultar tributação
- ✅ Atualizar IPI
- ✅ Análise de reforma tributária
- ✅ **Saneamento Tributário** (novo)
- ✅ Lote de operações

## 📝 Configuração de Proxy

O `bg.js` intercepta requisições para:
- `https://script.google.com/*` (Google Apps Script backend)
- `https://consultatributos.com.br/*` (API de saneamento)
- `https://*.totvs.com.br/*` (TOTVS ERP)

Removendo headers de CORS que causariam bloqueios em IPs restritos.

## 🔐 Segurança

⚠️ **IMPORTANTE**: Esta configuração:
- Desabilita segurança CORS apenas localmente
- Funciona apenas para desenvolvimento
- NÃO é segura para produção
- Use apenas em ambiente de teste

## 🐛 Troubleshooting

### Erro: "Extensão não aparece"
→ Verifique se o modo de desenvolvedor está ativo em `chrome://extensions/`

### Erro: "Não consegue conectar no servidor"
→ Certifique-se que a URL do WEB_APP_URL está correta em 5.3.html

### CORS ainda aparece
→ Tente limpar cache: `Ctrl + Shift + Delete`
→ Recarregue a página: `Ctrl + R` ou `F5`

### "Extensão removida/desabilitada"
→ Verifique `chrome://extensions/` e ative manualmente

## 📞 Contato

Para problemas, consulte:
- Backend: `5.3.1.gs` (Google Apps Script)
- Frontend: `5.3.html` (Interface)
- Proxy: `bg.js` + `proxy-helper.js`

---

**Versão:** 5.3.0  
**Última atualização:** 2026-08-14
